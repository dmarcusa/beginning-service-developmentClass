# Beginning .NET Service Development Class

## My Notes


## Links and Stuff
 

 To pull down my code, use `git pull`

 