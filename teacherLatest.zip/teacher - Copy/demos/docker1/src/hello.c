#include <stdio.h>

int main(void) {
    printf("I'm running in a container!\n");
    return (0);
}