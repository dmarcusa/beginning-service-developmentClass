create database employees

